# AVD2 — Herança e Polimorfismo (C#)

Solução em C# (.NET 8) contendo dois projetos console que resolvem os
exercícios práticos propostos no material de aula "AVD2 - Conteúdo: Herança".

## Estrutura da solução

```
AVD2_Heranca.sln
├── ControleBancario/              Exercícios das páginas 8 a 34
│   ├── Model/
│   │   ├── Cliente.cs
│   │   ├── Conta.cs                 (sobrecarga de construtor — slide 15)
│   │   ├── ContaCorrente.cs
│   │   ├── ContaEspecial.cs         (sobrescrita do Sacar — slide 26)
│   │   ├── ContaCaixinha.cs         (exercício — slide 34)
│   │   ├── Agencia.cs               (polimorfismo — slides 29-30)
│   │   ├── Calculadora.cs           (sobrecarga do método Maior — slides 20-21)
│   │   ├── Pessoa.cs / Funcionario.cs / Gerente.cs   (base/override — slides 22-25, 33)
│   │   └── Diretor.cs               (ordem de construtores — slide 14)
│   └── Program.cs                   Demonstra todos os exercícios acima
│
└── ControleFinanceiro/            Exercício "Pensando mais longe" (slide 35)
    ├── Model/
    │   ├── Pessoa.cs (abstrata) / PessoaFisica.cs / PessoaJuridica.cs
    │   ├── Credor.cs / Cliente.cs        (associação com Pessoa)
    │   └── Titulo.cs (abstrata) / ContaPagar.cs / ContaReceber.cs
    └── Program.cs                   Demonstra o cenário de contas a pagar/receber
```

## Como executar

Pré-requisito: [.NET SDK 8.0](https://dotnet.microsoft.com/download).

```bash
# Executar o projeto ControleBancario
cd ControleBancario
dotnet run

# Executar o projeto ControleFinanceiro
cd ../ControleFinanceiro
dotnet run
```

Ou, a partir da raiz, abrindo a solução completa no Visual Studio / Rider e
escolhendo o projeto de inicialização desejado.

## Exercícios resolvidos

### Questões de múltipla escolha (resposta + justificativa)

| Slide | Pergunta (resumo) | Resposta |
|---|---|---|
| 6 | Sintaxe correta de herança em C# | **A** — `class Carro : Veiculo` |
| 7 | O que a herança `Gerente : Funcionario` representa | **A, C, D** |
| 12 | Ordem de visibilidade, da menor para a maior | **B** — `private < protected < public` |
| 14 | Ordem de execução dos construtores (Funcionario → Diretor) | **C** |
| 16 | Alternativa que NÃO resolve o erro CS0246 | **B** |
| 17 | Calculadora com dois métodos `Calcular(double)` | **A** — não compila (assinaturas idênticas) |
| 18 | `TestaSobrecarga(1, 2.0)` | resolve para `(double, double)` |
| 19 | `Teste(1, 2)` com overloads `(double,int)`/`(int,double)` | ambíguo — erro de compilação |
| 31 | Saída de `contaCorrente.CalcularTaxaAdministrativa()` | **C** — será 0 |
| 32 | Por que o código de `Diretor`/`Funcionario` não compila | **A** |
| 33 | Bonificação de Gerente via referência Funcionario | **B** — 1500 |

A justificativa detalhada de cada uma está na documentação do trabalho
(arquivo .docx) e também como comentários no código, quando aplicável.

### Exercícios práticos de código

- Construção das classes `Cliente`, `Conta`, `ContaCorrente` e `ContaEspecial`
  do projeto `ControleBancario`, com a hierarquia de herança correta.
- Sobrecarga do construtor de `Conta` para saldo inicial padrão de 10,00.
- Sobrescrita do método `Sacar` em `ContaEspecial` considerando o limite.
- Criação da classe `ContaCaixinha` com as regras especiais de depósito e saque.
- Refatoração do método `Maior` (2 e 3 parâmetros) usando sobrecarga, eliminando repetição de código.
- Exercício "Pensando mais longe" (slide 35): modelagem e implementação do
  cenário de Pessoa Física/Jurídica, Credor/Cliente e Contas a Pagar/Receber.

## Tecnologias utilizadas

- C# / .NET 8
