namespace ControleFinanceiro.Model
{
    public class PessoaJuridica : Pessoa
    {
        public PessoaJuridica(string nome, string cnpj) : base(nome, cnpj)
        {
        }

        public override string DescreverTipo()
        {
            return "Pessoa Jurídica";
        }
    }
}
