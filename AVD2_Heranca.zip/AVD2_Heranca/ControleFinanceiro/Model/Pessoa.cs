namespace ControleFinanceiro.Model
{
    /// <summary>
    /// Exercício do slide 35: classe base abstrata para representar tanto
    /// pessoas físicas quanto jurídicas, já que a empresa precisa controlar
    /// informações sobre ambas de forma unificada.
    /// É abstrata porque não temos a intenção de instanciar uma "Pessoa"
    /// genérica diretamente — toda pessoa cadastrada deve ser, de fato,
    /// física ou jurídica.
    /// </summary>
    public abstract class Pessoa
    {
        public string Nome { get; set; }
        public string Documento { get; set; } // CPF ou CNPJ, conforme a subclasse

        protected Pessoa(string nome, string documento)
        {
            Nome = nome;
            Documento = documento;
        }

        public abstract string DescreverTipo();
    }
}
