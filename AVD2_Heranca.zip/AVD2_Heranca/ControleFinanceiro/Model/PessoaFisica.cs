namespace ControleFinanceiro.Model
{
    public class PessoaFisica : Pessoa
    {
        public PessoaFisica(string nome, string cpf) : base(nome, cpf)
        {
        }

        public override string DescreverTipo()
        {
            return "Pessoa Física";
        }
    }
}
