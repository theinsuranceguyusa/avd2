namespace ControleFinanceiro.Model
{
    /// <summary>
    /// Representa o papel de Credor que uma Pessoa (física ou jurídica) pode
    /// assumir. Optou-se por uma relação de ASSOCIAÇÃO (e não herança) entre
    /// Credor e Pessoa, pois uma mesma pessoa pode ser, ao mesmo tempo,
    /// Credora e Cliente da empresa — o que não seria possível representar
    /// corretamente com herança simples em C#.
    /// </summary>
    public class Credor
    {
        public Pessoa Pessoa { get; set; }

        public Credor(Pessoa pessoa)
        {
            Pessoa = pessoa;
        }
    }
}
