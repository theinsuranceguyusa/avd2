namespace ControleFinanceiro.Model
{
    /// <summary>
    /// Representa o papel de Cliente que uma Pessoa (física ou jurídica) pode
    /// assumir perante a empresa, pagando valores por meio de contas a
    /// receber. Assim como Credor, é uma associação com Pessoa.
    /// </summary>
    public class Cliente
    {
        public Pessoa Pessoa { get; set; }

        public Cliente(Pessoa pessoa)
        {
            Pessoa = pessoa;
        }
    }
}
