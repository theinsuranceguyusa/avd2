using System;

namespace ControleFinanceiro.Model
{
    /// <summary>
    /// Exercício do slide 35: "Contas a pagar e a receber são tipos de
    /// títulos que o controle financeiro da empresa manipula." Por isso,
    /// Titulo é a classe base (abstrata) de ContaPagar e ContaReceber,
    /// concentrando os atributos e comportamentos comuns a ambas.
    /// </summary>
    public abstract class Titulo
    {
        public double Valor { get; set; }
        public DateTime DataVencimento { get; set; }
        public bool Pago { get; private set; }

        protected Titulo(double valor, DateTime dataVencimento)
        {
            Valor = valor;
            DataVencimento = dataVencimento;
            Pago = false;
        }

        public virtual void Liquidar()
        {
            Pago = true;
        }
    }
}
