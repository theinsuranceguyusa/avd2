using System;

namespace ControleFinanceiro.Model
{
    /// <summary>
    /// "Sendo clientes pagam valores a empresa por meio de contas a
    /// receber" (slide 35). ContaReceber é uma especialização (herança) de
    /// Titulo e possui uma associação com Cliente, indicando de quem a
    /// empresa irá receber este título.
    /// </summary>
    public class ContaReceber : Titulo
    {
        public Cliente Cliente { get; set; }

        public ContaReceber(double valor, DateTime dataVencimento, Cliente cliente)
            : base(valor, dataVencimento)
        {
            Cliente = cliente;
        }

        public override void Liquidar()
        {
            base.Liquidar();
            Console.WriteLine($"Recebimento de {Valor:C2} confirmado do cliente {Cliente.Pessoa.Nome}.");
        }
    }
}
