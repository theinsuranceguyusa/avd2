using System;

namespace ControleFinanceiro.Model
{
    /// <summary>
    /// "Sendo credores recebem valores da empresa, por meio de contas a
    /// pagar" (slide 35). ContaPagar é uma especialização (herança) de
    /// Titulo e possui uma associação com Credor, indicando a quem a
    /// empresa deve pagar este título.
    /// </summary>
    public class ContaPagar : Titulo
    {
        public Credor Credor { get; set; }

        public ContaPagar(double valor, DateTime dataVencimento, Credor credor)
            : base(valor, dataVencimento)
        {
            Credor = credor;
        }

        public override void Liquidar()
        {
            base.Liquidar();
            Console.WriteLine($"Pagamento de {Valor:C2} efetuado ao credor {Credor.Pessoa.Nome}.");
        }
    }
}
