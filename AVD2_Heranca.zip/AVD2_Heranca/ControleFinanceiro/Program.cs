using System;
using ControleFinanceiro.Model;

namespace ControleFinanceiro
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("==========================================================");
            Console.WriteLine(" AVD2 - Heranca - Exercicio Pensando Mais Longe (slide 35)");
            Console.WriteLine("==========================================================\n");

            // Pessoa física que é, ao mesmo tempo, Cliente e Credora da empresa.
            Pessoa joao = new PessoaFisica("João Pedro Martins", "111.222.333-44");
            Cliente joaoComoCliente = new Cliente(joao);
            Credor joaoComoCredor = new Credor(joao);

            // Pessoa jurídica que é apenas Cliente.
            Pessoa empresaXyz = new PessoaJuridica("XYZ Materiais de Construção Ltda.", "12.345.678/0001-90");
            Cliente empresaXyzComoCliente = new Cliente(empresaXyz);

            Console.WriteLine($"{joao.Nome} ({joao.DescreverTipo()}) é cliente e também credor da empresa.");
            Console.WriteLine($"{empresaXyz.Nome} ({empresaXyz.DescreverTipo()}) é cliente da empresa.\n");

            // Conta a receber: a empresa cobra de João Pedro, como cliente.
            ContaReceber receberDeJoao = new ContaReceber(
                valor: 350.00,
                dataVencimento: new DateTime(2026, 7, 10),
                cliente: joaoComoCliente
            );

            // Conta a pagar: a empresa deve pagar a João Pedro, como credor.
            ContaPagar pagarParaJoao = new ContaPagar(
                valor: 1200.00,
                dataVencimento: new DateTime(2026, 7, 15),
                credor: joaoComoCredor
            );

            // Conta a receber da empresa XYZ.
            ContaReceber receberDaEmpresaXyz = new ContaReceber(
                valor: 5400.00,
                dataVencimento: new DateTime(2026, 8, 1),
                cliente: empresaXyzComoCliente
            );

            Console.WriteLine("--- Títulos antes da liquidação ---");
            ExibirTitulo(receberDeJoao, "Conta a receber (João Pedro)");
            ExibirTitulo(pagarParaJoao, "Conta a pagar (João Pedro)");
            ExibirTitulo(receberDaEmpresaXyz, "Conta a receber (Empresa XYZ)");

            Console.WriteLine("\n--- Liquidando os títulos ---");
            receberDeJoao.Liquidar();
            pagarParaJoao.Liquidar();
            receberDaEmpresaXyz.Liquidar();

            Console.WriteLine("\n--- Títulos após a liquidação ---");
            ExibirTitulo(receberDeJoao, "Conta a receber (João Pedro)");
            ExibirTitulo(pagarParaJoao, "Conta a pagar (João Pedro)");
            ExibirTitulo(receberDaEmpresaXyz, "Conta a receber (Empresa XYZ)");

            Console.WriteLine("\nFim da execução. Pressione qualquer tecla para sair...");
            Console.ReadKey();
        }

        static void ExibirTitulo(Titulo titulo, string descricao)
        {
            Console.WriteLine($"{descricao} | Valor: {titulo.Valor:C2} | Vencimento: {titulo.DataVencimento:dd/MM/yyyy} | Pago: {titulo.Pago}");
        }
    }
}
