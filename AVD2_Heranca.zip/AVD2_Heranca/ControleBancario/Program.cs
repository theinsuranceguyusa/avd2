using System;
using ControleBancario.Model;

namespace ControleBancario
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("================================================");
            Console.WriteLine(" AVD2 - Heranca e Polimorfismo - ControleBancario");
            Console.WriteLine("================================================\n");

            DemonstrarContaCorrenteEContaEspecial();
            DemonstrarContaComSaldoPadrao();
            DemonstrarContaCaixinha();
            DemonstrarPolimorfismoComAgencia();
            DemonstrarHerancaEBonificacao();
            DemonstrarOrdemDeConstrutores();
            DemonstrarSobrecargaCalculadora();

            Console.WriteLine("\nFim da execução. Pressione qualquer tecla para sair...");
            Console.ReadKey();
        }

        // Slides 8-11 e 26: ContaCorrente e ContaEspecial (sobrescrita do Sacar)
        static void DemonstrarContaCorrenteEContaEspecial()
        {
            Console.WriteLine("--- ContaCorrente x ContaEspecial (sobrescrita de Sacar) ---");

            var cliente = new Cliente("Marcos Vinicius", "12345678900");
            var contaCorrente = new ContaCorrente(cliente, 500);
            var contaEspecial = new ContaEspecial(cliente, 500, 300); // saldo 500, limite 300

            Console.WriteLine($"Saque de 600 na ContaCorrente (sem limite): {contaCorrente.Sacar(600)}");
            Console.WriteLine($"Saque de 600 na ContaEspecial (com limite de 300): {contaEspecial.Sacar(600)}");
            Console.WriteLine($"Saldo da ContaEspecial após o saque: {contaEspecial.Saldo:C2}\n");
        }

        // Slide 15: sobrecarga de construtor com saldo padrão de 10,00
        static void DemonstrarContaComSaldoPadrao()
        {
            Console.WriteLine("--- Sobrecarga de construtor: saldo inicial padrão ---");

            var cliente = new Cliente("Beatriz Souza", "98765432100");
            var contaComSaldoInformado = new Conta(cliente, 250.00);
            var contaComSaldoPadrao = new Conta(cliente); // usa o saldo padrão de 10,00

            Console.WriteLine($"Conta com saldo informado: {contaComSaldoInformado}");
            Console.WriteLine($"Conta com saldo padrão (10,00): {contaComSaldoPadrao}\n");
        }

        // Slide 34: ContaCaixinha
        static void DemonstrarContaCaixinha()
        {
            Console.WriteLine("--- ContaCaixinha (regras especiais de depósito/saque) ---");

            var cliente = new Cliente("Ricardo Alves", "11122233344");
            var caixinha = new ContaCaixinha(cliente, 50.00);

            caixinha.Depositar(20.00); // saldo esperado: 50 + 20 + 1 = 71
            Console.WriteLine($"Saldo após depósito de 20,00: {caixinha.Saldo:C2}");

            bool sucesso = caixinha.Sacar(10.00); // saldo esperado: 71 - 10 - 5 = 56
            Console.WriteLine($"Saque de 10,00 realizado? {sucesso} | Saldo: {caixinha.Saldo:C2}\n");
        }

        // Slides 29-30: polimorfismo com Agencia aceitando ContaCorrente e ContaEspecial
        static void DemonstrarPolimorfismoComAgencia()
        {
            Console.WriteLine("--- Polimorfismo: Agencia aceitando ContaCorrente e ContaEspecial ---");

            var cliente = new Cliente("Fernanda Lima", "55566677788");
            var cc = new ContaCorrente(cliente, 1000);
            var ce = new ContaEspecial(cliente, 500, 200);

            var agencia = new Agencia();
            agencia.InserirConta(cc); // aceita ContaCorrente
            agencia.InserirConta(ce); // aceita ContaEspecial, pois também é uma ContaCorrente

            Console.WriteLine($"Saldo total da agência: {agencia.CalcularTotal():C2}\n");
        }

        // Slides 22-25 e 33: herança, base() e polimorfismo na bonificação
        static void DemonstrarHerancaEBonificacao()
        {
            Console.WriteLine("--- Herança e polimorfismo: bonificação de Funcionario x Gerente ---");

            Gerente gerente = new Gerente("Camila Rocha", 35);
            Funcionario funcionario = gerente; // upcasting
            funcionario.Salario = 5000.00;

            // Mesmo a variável sendo do tipo Funcionario, o método chamado em
            // tempo de execução é o de Gerente (polimorfismo), pois GetBonificacao
            // foi declarado virtual em Funcionario e sobrescrito (override) em Gerente.
            Console.WriteLine($"Bonificação calculada (esperado 1500,00): {funcionario.GetBonificacao():C2}\n");
        }

        // Slide 14: ordem de execução dos construtores em uma hierarquia de herança
        static void DemonstrarOrdemDeConstrutores()
        {
            Console.WriteLine("--- Ordem de execução de construtores (Funcionario -> Diretor) ---");
            var diretor = new Diretor(); // imprime "Funcionario" e depois "Diretor"
            Console.WriteLine();
        }

        // Slides 20-21: sobrecarga do método Maior, evitando repetição de código
        static void DemonstrarSobrecargaCalculadora()
        {
            Console.WriteLine("--- Sobrecarga de método: Calculadora.Maior ---");
            var calculadora = new Calculadora();

            Console.WriteLine($"Maior entre 4 e 9: {calculadora.Maior(4, 9)}");
            Console.WriteLine($"Maior entre 4, 9 e 7: {calculadora.Maior(4, 9, 7)}\n");
        }
    }
}
