using System;

namespace ControleBancario.Model
{
    /// <summary>
    /// Classe base que representa uma conta bancária genérica.
    /// Exercício de Fixação (slide 15): toda conta deve ter um saldo inicial,
    /// que quando não informado assume o valor de 10,00. Isso foi resolvido
    /// com sobrecarga de construtores: um construtor recebe cliente e saldo,
    /// outro recebe apenas o cliente e delega ao primeiro usando "this(...)".
    /// </summary>
    public class Conta
    {
        private long numero;
        protected double saldo;
        protected Cliente titular;

        private static long proximoNumero = 1000;

        public long Numero => numero;

        public double Saldo => saldo;

        public Cliente Titular => titular;

        // Construtor que recebe cliente e saldo inicial.
        public Conta(Cliente cliente, double saldo)
        {
            this.titular = cliente;
            this.saldo = saldo;
            this.numero = proximoNumero++;
        }

        // Construtor que recebe apenas o cliente; delega ao construtor
        // principal informando o saldo padrão de 10,00.
        public Conta(Cliente cliente) : this(cliente, 10.00)
        {
        }

        public void Depositar(double valor)
        {
            if (valor > 0)
            {
                saldo += valor;
            }
        }

        public virtual bool Sacar(double valor)
        {
            if (valor > 0 && valor <= saldo)
            {
                saldo -= valor;
                return true;
            }
            return false;
        }

        public virtual void Transferir(Conta destino, double valor)
        {
            if (Sacar(valor))
            {
                destino.Depositar(valor);
            }
        }

        public override string ToString()
        {
            return $"Conta {numero} | Titular: {titular.Nome} | Saldo: {saldo:C2}";
        }
    }
}
