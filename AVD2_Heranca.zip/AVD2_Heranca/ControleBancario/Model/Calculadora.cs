namespace ControleBancario.Model
{
    /// <summary>
    /// Exercício dos slides 20-21: o método Maior(a,b,c) inicialmente repetia
    /// lógica de comparação. A solução elegante apresentada usa sobrecarga:
    /// a versão de 3 parâmetros reaproveita a versão de 2 parâmetros
    /// ("dividir para conquistar"), eliminando a duplicação de código.
    /// </summary>
    public class Calculadora
    {
        // Sobrecarga 1: maior entre dois valores.
        public double Maior(double a, double b)
        {
            if (a > b)
            {
                return a;
            }
            return b;
        }

        // Sobrecarga 2: maior entre três valores, reaproveitando a sobrecarga de 2.
        public double Maior(double a, double b, double c)
        {
            double maiorEntreAeB = Maior(a, b);
            return Maior(maiorEntreAeB, c);
        }
    }
}
