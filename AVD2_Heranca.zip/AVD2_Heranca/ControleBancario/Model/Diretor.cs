using System;

namespace ControleBancario.Model
{
    /// <summary>
    /// Demonstra (slide 14) a ordem de execução de construtores em uma
    /// hierarquia de herança: ao instanciar Diretor, o construtor da classe
    /// base Funcionario é executado implicitamente ANTES do construtor de
    /// Diretor, mesmo sem chamada explícita a base(...) — desde que a classe
    /// base possua um construtor sem parâmetros disponível.
    ///
    /// Observação: como, no projeto, Funcionario só possui construtor com
    /// parâmetros (nome, idade), esta classe Diretor de demonstração utiliza
    /// uma versão simplificada apenas para ilustrar a ordem de chamada dos
    /// construtores com Console.WriteLine, replicando o exemplo do slide 14.
    /// </summary>
    public class FuncionarioBase
    {
        public FuncionarioBase()
        {
            Console.WriteLine("Funcionario");
        }
    }

    public class Diretor : FuncionarioBase
    {
        public Diretor()
        {
            Console.WriteLine("Diretor");
        }
    }
}
