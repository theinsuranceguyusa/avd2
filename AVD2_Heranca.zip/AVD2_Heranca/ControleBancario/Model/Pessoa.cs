namespace ControleBancario.Model
{
    /// <summary>
    /// Classe base usada nos exemplos de construtores e do identificador
    /// "base" apresentados nos slides 13 e 22-25.
    /// </summary>
    public class Pessoa
    {
        public string Nome { get; set; }
        public int Idade { get; set; }

        public Pessoa(string nome, int idade)
        {
            Nome = nome;
            Idade = idade;
        }
    }
}
