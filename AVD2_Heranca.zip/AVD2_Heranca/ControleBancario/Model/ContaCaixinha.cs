namespace ControleBancario.Model
{
    /// <summary>
    /// Exercício do slide 34: ContaCaixinha é uma subclasse de Conta com
    /// comportamento diferenciado:
    /// - A cada depósito, o saldo é incrementado em 1,00 além do valor depositado.
    /// - A cada saque, o saldo é decrementado em 5,00 além do valor sacado.
    /// - Não são permitidos depósitos inferiores a 1,00.
    /// </summary>
    public class ContaCaixinha : Conta
    {
        public ContaCaixinha(Cliente cliente, double saldo) : base(cliente, saldo)
        {
        }

        public ContaCaixinha(Cliente cliente) : base(cliente)
        {
        }

        // Observação de design: o método Depositar da classe base Conta não
        // foi declarado virtual, então aqui usamos "new" para ocultar
        // (esconder) a implementação da base com uma nova implementação,
        // em vez de sobrescrevê-la (override). Isso significa que, se um
        // ContaCaixinha for referenciado por uma variável do tipo Conta,
        // o comportamento padrão de Depositar (sem o acréscimo de 1,00)
        // será executado — diferente do que ocorre com Sacar, que É virtual
        // na base e, portanto, sobrescrito (override) corretamente abaixo.
        public new void Depositar(double valor)
        {
            if (valor >= 1.00)
            {
                saldo += valor + 1.00;
            }
        }

        public override bool Sacar(double valor)
        {
            double valorTotal = valor + 5.00;
            if (valor > 0 && valorTotal <= saldo)
            {
                saldo -= valorTotal;
                return true;
            }
            return false;
        }
    }
}
