namespace ControleBancario.Model
{
    /// <summary>
    /// Conta corrente padrão. Não acrescenta novos comportamentos em relação
    /// à classe base Conta, mas existe como ponto de extensão da hierarquia,
    /// conforme o diagrama apresentado em aula (slide 8-10).
    /// </summary>
    public class ContaCorrente : Conta
    {
        public ContaCorrente(Cliente cliente, double saldo) : base(cliente, saldo)
        {
        }

        public ContaCorrente(Cliente cliente) : base(cliente)
        {
        }
    }
}
