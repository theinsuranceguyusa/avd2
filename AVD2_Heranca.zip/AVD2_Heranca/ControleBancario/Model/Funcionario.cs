namespace ControleBancario.Model
{
    /// <summary>
    /// Demonstra (slides 22-25):
    /// - chamada explícita ao construtor da superclasse com "base(n, i)",
    ///   necessária pois a classe Pessoa não possui construtor padrão sem parâmetros;
    /// - o método GetBonificacao() é marcado como virtual para permitir
    ///   sobrescrita (override) nas subclasses Gerente e Diretor.
    /// </summary>
    public class Funcionario : Pessoa
    {
        public double Salario { get; set; }

        public Funcionario(string nome, int idade) : base(nome, idade)
        {
        }

        public virtual double GetBonificacao()
        {
            return Salario * 0.10;
        }
    }
}
