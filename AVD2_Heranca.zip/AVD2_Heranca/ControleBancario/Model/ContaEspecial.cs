namespace ControleBancario.Model
{
    /// <summary>
    /// Conta especial: é uma ContaCorrente que possui um limite adicional.
    /// O método Sacar é sobrescrito (slide 26) para considerar esse limite
    /// extra, e o método Transferir também é sobrescrito para utilizar o
    /// novo comportamento de Sacar.
    /// </summary>
    public class ContaEspecial : ContaCorrente
    {
        private double limite;

        public double Limite => limite;

        public ContaEspecial(Cliente cliente, double saldo, double limite) : base(cliente, saldo)
        {
            this.limite = limite;
        }

        public ContaEspecial(Cliente cliente, double limite) : base(cliente)
        {
            this.limite = limite;
        }

        // Sobrescrita do método Sacar: agora o valor sacado pode ultrapassar
        // o saldo, desde que respeite o limite adicional da conta especial.
        public override bool Sacar(double valor)
        {
            if (valor <= limite + saldo)
            {
                saldo -= valor;
                return true;
            }
            return false;
        }
    }
}
