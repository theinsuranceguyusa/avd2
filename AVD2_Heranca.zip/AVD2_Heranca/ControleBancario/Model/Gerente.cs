namespace ControleBancario.Model
{
    /// <summary>
    /// Demonstra (slides 24-25 e exercício de revisão do slide 33):
    /// sobrescrita de método (override) reaproveitando a implementação da
    /// classe base por meio de base.GetBonificacao(), e somando o valor
    /// fixo de bonificação de R$1000,00 concedido a gerentes.
    /// </summary>
    public class Gerente : Funcionario
    {
        public Gerente(string nome, int idade) : base(nome, idade)
        {
        }

        public override double GetBonificacao()
        {
            return base.GetBonificacao() + 1000;
        }
    }
}
