using System;

namespace ControleBancario.Model
{
    /// <summary>
    /// Representa o cliente titular de uma conta bancária.
    /// </summary>
    public class Cliente
    {
        public string Nome { get; set; }
        public string Cpf { get; set; }
        public string Email { get; set; }
        public int AnoNascimento { get; set; }

        public Cliente(string nome, string cpf)
        {
            Nome = nome;
            Cpf = cpf;
        }
    }
}
