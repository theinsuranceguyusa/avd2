using System.Collections.Generic;
using System.Linq;

namespace ControleBancario.Model
{
    /// <summary>
    /// Demonstra o conceito de polimorfismo apresentado nos slides 29-30:
    /// a Agencia trabalha com referências do tipo ContaCorrente, mas aceita
    /// também objetos de subclasses como ContaEspecial, pois, pela hierarquia
    /// de herança, toda ContaEspecial também É UMA ContaCorrente.
    /// </summary>
    public class Agencia
    {
        private List<ContaCorrente> contas = new List<ContaCorrente>();

        public void InserirConta(ContaCorrente conta)
        {
            contas.Add(conta);
        }

        public double CalcularTotal()
        {
            return contas.Sum(c => c.Saldo);
        }
    }
}
