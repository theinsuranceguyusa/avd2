# Sistema Escolar (C# + Entity Framework Core + MySQL)

Aplicação console em C# que demonstra persistência de dados em banco de
dados relacional (MySQL), um relacionamento de associação entre duas
classes (`Turma` e `Aluno`) e três consultas LINQ distintas.

## Contexto escolhido

O sistema modela um cenário escolar simples: uma escola possui **Turmas**
(ex.: "3º Ano A"), e cada **Turma** possui vários **Alunos** matriculados.
Cada aluno possui uma média final e um indicador de situação (ativo/inativo).

## Estrutura do projeto

```
EscolaApp/
├── EscolaApp.csproj          # Definição do projeto e dependências (NuGet)
├── Program.cs                 # Ponto de entrada: seed de dados e consultas LINQ
├── Models/
│   ├── Turma.cs                # Classe Turma (lado "um" da associação)
│   └── Aluno.cs                 # Classe Aluno (lado "muitos" da associação)
└── Data/
    └── EscolaContext.cs         # DbContext do Entity Framework Core (persistência)
```

## Relacionamento entre as classes

`Turma` (1) ----- (N) `Aluno`

Uma turma possui uma coleção de alunos (`Turma.Alunos`), e cada aluno faz
referência à turma à qual pertence (`Aluno.Turma` / `Aluno.TurmaId`). Esse é
um relacionamento de **associação** (um objeto utiliza/contém referência ao
outro, mas ambos podem existir de forma independente em termos de ciclo de
vida conceitual).

## Pré-requisitos para executar

1. [.NET SDK 8.0](https://dotnet.microsoft.com/download) instalado.
2. Um servidor **MySQL** (local ou remoto) em execução.
3. Ajustar a string de conexão em `Data/EscolaContext.cs` conforme seu
   ambiente (servidor, porta, usuário, senha, nome do banco):

```csharp
private const string ConnectionString =
    "server=localhost;port=3306;database=escola_db;user=root;password=root;TreatTinyAsBoolean=true";
```

## Como executar

```bash
# Restaurar dependências (Pomelo.EntityFrameworkCore.MySql)
dotnet restore

# Compilar
dotnet build

# Executar (cria automaticamente o banco/tabelas e popula com dados iniciais)
dotnet run
```

Na primeira execução, o método `EnsureCreated()` cria o banco de dados e as
tabelas `Turmas` e `Alunos` no MySQL, e o método `PopularBancoSeNecessario`
insere alguns registros de exemplo. Nas execuções seguintes, os dados já
persistidos são reaproveitados.

## Consultas LINQ implementadas

### Consulta 1 — Dados das duas classes
**Enunciado:** Listar o nome de cada aluno ativo junto com o nome e o turno
da turma em que ele está matriculado, ordenado por nome da turma.
Implementada com `join` explícito entre `Alunos` e `Turmas`.

### Consulta 2 — Função de grupo (agregação)
**Enunciado:** Calcular a média final dos alunos e a quantidade de alunos,
agrupados por turma. Implementada com `GroupBy` + `Average` + `Count`.

### Consulta 3 — Filtro principal (WHERE) e filtro de grupo (HAVING)
**Enunciado:** Entre os alunos ativos (filtro `Where` aplicado antes do
agrupamento, equivalente à cláusula `WHERE` em SQL), identificar as turmas
que possuem mais de 2 alunos ativos **e** média final do grupo maior ou
igual a 8.0 (filtro `Where` aplicado após o `GroupBy`, equivalente à
cláusula `HAVING` em SQL).

## Tecnologias utilizadas

- C# / .NET 8
- Entity Framework Core 8
- Pomelo.EntityFrameworkCore.MySql (provedor MySQL para EF Core)
- MySQL Server
