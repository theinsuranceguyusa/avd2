using System;
using System.Linq;
using Microsoft.EntityFrameworkCore;
using EscolaApp.Data;
using EscolaApp.Models;

namespace EscolaApp
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("=========================================");
            Console.WriteLine(" Sistema Escolar - Persistencia + LINQ   ");
            Console.WriteLine("=========================================\n");

            using (var contexto = new EscolaContext())
            {
                // Garante que o banco e as tabelas existam (cria o schema se necessário).
                contexto.Database.EnsureCreated();

                PopularBancoSeNecessario(contexto);

                ConsultaUm_AlunosComSuaTurma(contexto);
                ConsultaDois_MediaDeAlunosPorTurma(contexto);
                ConsultaTres_TurmasComMediaAltaEMaisDeDoisAlunos(contexto);
            }

            Console.WriteLine("\nFim da execução. Pressione qualquer tecla para sair...");
            Console.ReadKey();
        }

        /// <summary>
        /// Insere dados iniciais (seed) apenas se o banco ainda estiver vazio,
        /// demonstrando a persistência de dados das classes Turma e Aluno.
        /// </summary>
        static void PopularBancoSeNecessario(EscolaContext contexto)
        {
            if (contexto.Turmas.Any())
            {
                Console.WriteLine("Banco de dados já populado. Pulando inserção inicial.\n");
                return;
            }

            Console.WriteLine("Populando banco de dados com dados iniciais...\n");

            var turma3A = new Turma { Nome = "3º Ano A", Turno = "Manhã", AnoLetivo = 2026 };
            var turma3B = new Turma { Nome = "3º Ano B", Turno = "Tarde", AnoLetivo = 2026 };
            var turma2A = new Turma { Nome = "2º Ano A", Turno = "Manhã", AnoLetivo = 2026 };

            turma3A.Alunos.Add(new Aluno { Nome = "Ana Souza",     DataNascimento = new DateTime(2008, 3, 12), MediaFinal = 9.2, Ativo = true });
            turma3A.Alunos.Add(new Aluno { Nome = "Bruno Lima",    DataNascimento = new DateTime(2008, 7, 25), MediaFinal = 7.8, Ativo = true });
            turma3A.Alunos.Add(new Aluno { Nome = "Carla Mendes",  DataNascimento = new DateTime(2008, 1, 30), MediaFinal = 8.5, Ativo = true });

            turma3B.Alunos.Add(new Aluno { Nome = "Diego Alves",   DataNascimento = new DateTime(2008, 5, 18), MediaFinal = 6.4, Ativo = true });
            turma3B.Alunos.Add(new Aluno { Nome = "Eduarda Rocha", DataNascimento = new DateTime(2008, 9, 2),  MediaFinal = 9.5, Ativo = true });

            turma2A.Alunos.Add(new Aluno { Nome = "Felipe Costa",  DataNascimento = new DateTime(2009, 4, 10), MediaFinal = 8.9, Ativo = true });
            turma2A.Alunos.Add(new Aluno { Nome = "Gabriela Dias", DataNascimento = new DateTime(2009, 11, 5), MediaFinal = 9.1, Ativo = false });
            turma2A.Alunos.Add(new Aluno { Nome = "Hugo Pereira",  DataNascimento = new DateTime(2009, 8, 22), MediaFinal = 7.0, Ativo = true });

            contexto.Turmas.AddRange(turma3A, turma3B, turma2A);
            contexto.SaveChanges(); // Persistência efetiva no banco de dados MySQL

            Console.WriteLine("Dados iniciais gravados com sucesso.\n");
        }

        /// <summary>
        /// CONSULTA 1 (usa dados das duas classes - Aluno e Turma):
        /// "Listar o nome de cada aluno ativo junto com o nome e o turno da turma
        ///  em que ele está matriculado, ordenados por nome da turma."
        /// Demonstra uma junção (join implícito via navegação) entre Aluno e Turma.
        /// </summary>
        static void ConsultaUm_AlunosComSuaTurma(EscolaContext contexto)
        {
            Console.WriteLine("---------------------------------------------------------");
            Console.WriteLine("CONSULTA 1: Alunos ativos e a turma em que estão matriculados");
            Console.WriteLine("---------------------------------------------------------");

            var resultado = from aluno in contexto.Alunos
                             join turma in contexto.Turmas on aluno.TurmaId equals turma.TurmaId
                             where aluno.Ativo
                             orderby turma.Nome, aluno.Nome
                             select new
                             {
                                 aluno.Nome,
                                 TurmaNome = turma.Nome,
                                 turma.Turno
                             };

            foreach (var item in resultado)
            {
                Console.WriteLine($"Aluno: {item.Nome,-20} | Turma: {item.TurmaNome,-10} | Turno: {item.Turno}");
            }

            Console.WriteLine();
        }

        /// <summary>
        /// CONSULTA 2 (utiliza função de grupo):
        /// "Calcular a média final dos alunos e a quantidade de alunos, agrupados por turma."
        /// Demonstra o uso de GroupBy combinado com as funções de agregação Average e Count.
        /// </summary>
        static void ConsultaDois_MediaDeAlunosPorTurma(EscolaContext contexto)
        {
            Console.WriteLine("---------------------------------------------------------");
            Console.WriteLine("CONSULTA 2: Média final e quantidade de alunos por turma");
            Console.WriteLine("---------------------------------------------------------");

            var resultado = contexto.Alunos
                .GroupBy(a => a.Turma!.Nome)
                .Select(g => new
                {
                    Turma = g.Key,
                    QuantidadeAlunos = g.Count(),
                    MediaDaTurma = g.Average(a => a.MediaFinal)
                })
                .OrderByDescending(x => x.MediaDaTurma);

            foreach (var item in resultado)
            {
                Console.WriteLine($"Turma: {item.Turma,-10} | Qtde. Alunos: {item.QuantidadeAlunos} | Média: {item.MediaDaTurma:F2}");
            }

            Console.WriteLine();
        }

        /// <summary>
        /// CONSULTA 3 (filtro principal WHERE + filtro de grupo HAVING):
        /// "Entre os alunos ATIVOS (filtro WHERE), identificar as turmas que possuem
        ///  mais de 2 alunos ativos E média final do grupo maior ou igual a 8.0 (filtro HAVING)."
        /// Demonstra Where antes do agrupamento (filtro de linhas) e a clausula equivalente
        /// a HAVING em LINQ, que é um Where aplicado depois do GroupBy (filtro de grupos).
        /// </summary>
        static void ConsultaTres_TurmasComMediaAltaEMaisDeDoisAlunos(EscolaContext contexto)
        {
            Console.WriteLine("---------------------------------------------------------");
            Console.WriteLine("CONSULTA 3: Turmas com mais de 2 alunos ativos e média >= 8.0");
            Console.WriteLine("---------------------------------------------------------");

            var resultado = contexto.Alunos
                .Where(a => a.Ativo) // filtro principal (equivalente ao WHERE), aplicado antes do agrupamento
                .GroupBy(a => a.Turma!.Nome)
                .Select(g => new
                {
                    Turma = g.Key,
                    QuantidadeAlunosAtivos = g.Count(),
                    MediaDoGrupo = g.Average(a => a.MediaFinal)
                })
                .Where(g => g.QuantidadeAlunosAtivos > 2 && g.MediaDoGrupo >= 8.0); // filtro do grupo (equivalente ao HAVING)

            bool algumResultado = false;
            foreach (var item in resultado)
            {
                algumResultado = true;
                Console.WriteLine($"Turma: {item.Turma,-10} | Alunos ativos: {item.QuantidadeAlunosAtivos} | Média do grupo: {item.MediaDoGrupo:F2}");
            }

            if (!algumResultado)
            {
                Console.WriteLine("Nenhuma turma atende aos critérios definidos.");
            }

            Console.WriteLine();
        }
    }
}
