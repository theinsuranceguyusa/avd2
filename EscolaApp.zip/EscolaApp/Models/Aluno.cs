using System;

namespace EscolaApp.Models
{
    /// <summary>
    /// Representa um aluno matriculado na escola.
    /// Cada Aluno pertence a exatamente uma Turma (chave estrangeira TurmaId),
    /// caracterizando o relacionamento de associação entre Aluno e Turma.
    /// </summary>
    public class Aluno
    {
        public int AlunoId { get; set; }

        public string Nome { get; set; } = string.Empty;

        public DateTime DataNascimento { get; set; }

        public double MediaFinal { get; set; } // Média final do aluno no ano letivo (0 a 10)

        public bool Ativo { get; set; } = true; // Indica se o aluno está ativo na escola

        // Chave estrangeira para a Turma à qual o aluno pertence.
        public int TurmaId { get; set; }

        // Propriedade de navegação: lado "um" do relacionamento de associação.
        public Turma? Turma { get; set; }

        public override string ToString()
        {
            return $"{Nome} (Média: {MediaFinal:F1})";
        }
    }
}
