using System.Collections.Generic;

namespace EscolaApp.Models
{
    /// <summary>
    /// Representa uma turma da escola (ex.: "3º Ano A - Ensino Médio").
    /// Uma Turma está associada a vários Alunos (relacionamento 1 para N).
    /// </summary>
    public class Turma
    {
        public int TurmaId { get; set; }

        public string Nome { get; set; } = string.Empty;

        public string Turno { get; set; } = string.Empty; // Manhã, Tarde ou Noite

        public int AnoLetivo { get; set; }

        // Propriedade de navegação: coleção de alunos pertencentes a esta turma.
        // Este é o lado "muitos" do relacionamento de associação Turma 1 --- N Aluno.
        public List<Aluno> Alunos { get; set; } = new List<Aluno>();

        public override string ToString()
        {
            return $"{Nome} ({Turno}/{AnoLetivo})";
        }
    }
}
