using Microsoft.EntityFrameworkCore;
using EscolaApp.Models;

namespace EscolaApp.Data
{
    /// <summary>
    /// Contexto do Entity Framework Core responsável pela persistência dos dados
    /// das classes Turma e Aluno em um banco de dados MySQL.
    /// </summary>
    public class EscolaContext : DbContext
    {
        // String de conexão com o banco MySQL.
        // Ajuste servidor, porta, usuário, senha e nome do banco conforme seu ambiente.
        private const string ConnectionString =
            "server=localhost;port=3306;database=escola_db;user=root;password=root;TreatTinyAsBoolean=true";

        public DbSet<Turma> Turmas { get; set; } = null!;
        public DbSet<Aluno> Alunos { get; set; } = null!;

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            optionsBuilder.UseMySql(
                ConnectionString,
                ServerVersion.AutoDetect(ConnectionString)
            );
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            // Configuração da entidade Turma
            modelBuilder.Entity<Turma>(entity =>
            {
                entity.HasKey(t => t.TurmaId);
                entity.Property(t => t.Nome).IsRequired().HasMaxLength(100);
                entity.Property(t => t.Turno).IsRequired().HasMaxLength(20);
            });

            // Configuração da entidade Aluno e do relacionamento de associação
            // Turma (1) ---- (N) Aluno
            modelBuilder.Entity<Aluno>(entity =>
            {
                entity.HasKey(a => a.AlunoId);
                entity.Property(a => a.Nome).IsRequired().HasMaxLength(150);

                entity.HasOne(a => a.Turma)          // Um Aluno possui uma Turma
                      .WithMany(t => t.Alunos)        // Uma Turma possui muitos Alunos
                      .HasForeignKey(a => a.TurmaId)
                      .OnDelete(DeleteBehavior.Cascade);
            });
        }
    }
}
